
export interface MeasurementResult {
  objectName: string;
  width: string;
  height: string;
  depth?: string;
  unit: 'cm' | 'inches' | 'meters';
  confidence: number;
  reasoning: string;
}

export enum AppState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  RESULT = 'RESULT',
  ERROR = 'ERROR'
}

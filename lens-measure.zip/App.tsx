
import React, { useState, useCallback } from 'react';
import CameraFeed from './components/CameraFeed';
import ResultCard from './components/ResultCard';
import { estimateMeasurement } from './services/geminiService';
import { MeasurementResult, AppState } from './types';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [result, setResult] = useState<MeasurementResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCapture = useCallback(async (base64Image: string) => {
    setAppState(AppState.LOADING);
    setErrorMsg(null);
    
    try {
      const data = await estimateMeasurement(base64Image);
      setResult(data);
      setAppState(AppState.RESULT);
    } catch (error: any) {
      console.error(error);
      setErrorMsg(error.message || "Something went wrong.");
      setAppState(AppState.ERROR);
      
      // Auto-clear error after 5 seconds
      setTimeout(() => {
        setAppState(AppState.IDLE);
        setErrorMsg(null);
      }, 5000);
    }
  }, []);

  const reset = () => {
    setAppState(AppState.IDLE);
    setResult(null);
    setErrorMsg(null);
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col h-screen select-none overflow-hidden">
      {/* Camera Layer */}
      <CameraFeed 
        onCapture={handleCapture} 
        isCapturing={appState === AppState.LOADING} 
      />

      {/* Loading Overlay */}
      {appState === AppState.LOADING && (
        <div className="absolute inset-0 z-40 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-300">
           <div className="relative mb-8">
              <div className="w-20 h-20 border-4 border-yellow-400/20 border-t-yellow-400 rounded-full animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                  <i className="fas fa-ruler text-2xl text-yellow-400 animate-pulse"></i>
              </div>
           </div>
           <h2 className="text-2xl font-bold text-white mb-2">Analyzing Image...</h2>
           <p className="text-zinc-400 max-w-xs">
             Gemini is calculating dimensions based on environmental visual cues.
           </p>
        </div>
      )}

      {/* Result Layer */}
      {appState === AppState.RESULT && result && (
        <ResultCard result={result} onClose={reset} />
      )}

      {/* Error Toast */}
      {appState === AppState.ERROR && errorMsg && (
        <div className="fixed top-20 inset-x-4 z-50 animate-in slide-in-from-top-10">
          <div className="bg-red-500/90 backdrop-blur-md text-white p-4 rounded-2xl flex items-center gap-4 shadow-xl border border-red-400/30">
            <i className="fas fa-exclamation-triangle text-xl"></i>
            <p className="text-sm font-medium">{errorMsg}</p>
          </div>
        </div>
      )}

      {/* Status Bar Indicator */}
      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center pointer-events-none opacity-50">
          <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
              <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-tighter">AI Vision Active</span>
          </div>
          <span className="text-[10px] text-zinc-400 font-mono tracking-tighter uppercase">Gemini-3-Flash</span>
      </div>
    </div>
  );
};

export default App;


import React from 'react';
import { MeasurementResult } from '../types';

interface ResultCardProps {
  result: MeasurementResult;
  onClose: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ result, onClose }) => {
  return (
    <div className="fixed inset-x-4 bottom-10 z-50 animate-in slide-in-from-bottom-10 duration-300">
      <div className="bg-zinc-900/90 backdrop-blur-xl border border-white/20 rounded-3xl overflow-hidden shadow-2xl">
        <div className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">Estimated Object</h2>
              <h3 className="text-white text-2xl font-bold">{result.objectName}</h3>
            </div>
            <button 
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-full bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>

          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="bg-zinc-800/50 p-3 rounded-2xl border border-white/5">
              <span className="block text-zinc-500 text-[10px] font-bold uppercase mb-1">Width</span>
              <span className="text-xl font-mono text-yellow-400">{result.width}</span>
            </div>
            <div className="bg-zinc-800/50 p-3 rounded-2xl border border-white/5">
              <span className="block text-zinc-500 text-[10px] font-bold uppercase mb-1">Height</span>
              <span className="text-xl font-mono text-yellow-400">{result.height}</span>
            </div>
            <div className="bg-zinc-800/50 p-3 rounded-2xl border border-white/5">
              <span className="block text-zinc-500 text-[10px] font-bold uppercase mb-1">Depth</span>
              <span className="text-xl font-mono text-yellow-400">{result.depth || '--'}</span>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-zinc-500 font-bold uppercase">Confidence Score</span>
                <span className="text-zinc-300 font-mono">{(result.confidence * 100).toFixed(0)}%</span>
              </div>
              <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-yellow-400 rounded-full transition-all duration-1000"
                  style={{ width: `${result.confidence * 100}%` }}
                ></div>
              </div>
            </div>

            <div className="bg-white/5 p-4 rounded-xl">
               <h4 className="text-xs font-bold text-zinc-400 uppercase mb-2 flex items-center gap-2">
                  <i className="fas fa-brain text-purple-400"></i>
                  AI Reasoning
               </h4>
               <p className="text-sm text-zinc-300 leading-relaxed italic">
                 "{result.reasoning}"
               </p>
            </div>
          </div>
        </div>
        
        <button 
          onClick={onClose}
          className="w-full py-4 bg-yellow-400 text-zinc-950 font-bold text-sm uppercase tracking-widest hover:bg-yellow-300 transition-colors"
        >
          Measure Another
        </button>
      </div>
    </div>
  );
};

export default ResultCard;

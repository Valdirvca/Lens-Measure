
import React, { useRef, useEffect, useState, useCallback } from 'react';

interface CameraFeedProps {
  onCapture: (base64Image: string) => void;
  isCapturing: boolean;
}

const CameraFeed: React.FC<CameraFeedProps> = ({ onCapture, isCapturing }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  const startCamera = useCallback(async () => {
    setIsInitializing(true);
    setError(null);
    let stream: MediaStream | null = null;

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment', 
          width: { ideal: 1920 }, 
          height: { ideal: 1080 } 
        },
        audio: false,
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.onloadedmetadata = () => {
          setIsInitializing(false);
        };
      }
    } catch (err: any) {
      console.error("Camera access error:", err);
      setIsInitializing(false);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setError("Camera access was denied. Please check your browser settings and the address bar to allow camera permissions.");
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setError("No camera found on this device.");
      } else {
        setError("An error occurred while accessing the camera: " + err.message);
      }
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, [startCamera]);

  const handleCapture = useCallback(() => {
    if (videoRef.current && canvasRef.current && !isCapturing && !error) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      const context = canvas.getContext('2d');

      if (context) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert to base64
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const base64 = dataUrl.split(',')[1];
        onCapture(base64);
      }
    }
  }, [onCapture, isCapturing, error]);

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-zinc-950 text-zinc-100">
        <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mb-6 border border-red-500/20">
          <i className="fas fa-camera-slash text-3xl text-red-500"></i>
        </div>
        <p className="text-xl font-bold mb-3 tracking-tight">Camera Access Required</p>
        <p className="text-zinc-400 text-sm mb-8 max-w-xs leading-relaxed">
          {error}
        </p>
        <button 
          onClick={startCamera}
          className="px-8 py-3 bg-white text-zinc-950 rounded-full font-bold text-sm uppercase tracking-widest hover:bg-zinc-200 transition-all active:scale-95 flex items-center gap-2 shadow-lg"
        >
          <i className="fas fa-redo-alt"></i>
          Grant Access
        </button>
        <p className="mt-8 text-[10px] text-zinc-600 uppercase tracking-widest">
          Check site settings in your browser address bar
        </p>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full bg-black overflow-hidden flex items-center justify-center">
      {isInitializing && (
        <div className="absolute inset-0 z-10 bg-zinc-950 flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-2 border-zinc-800 border-t-yellow-400 rounded-full animate-spin mb-4"></div>
          <p className="text-xs text-zinc-500 uppercase tracking-widest">Initializing Lens...</p>
        </div>
      )}

      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute w-full h-full object-cover"
      />
      
      {/* Target Reticle */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-0">
        <div className="w-64 h-64 border-2 border-dashed border-white/20 rounded-3xl flex items-center justify-center">
            <div className="w-4 h-4 border-2 border-yellow-400/50 rounded-full bg-yellow-400/10"></div>
        </div>
      </div>

      {/* Shutter Button Container */}
      <div className="absolute bottom-12 left-0 right-0 flex justify-center items-center z-20">
        <button
          onClick={handleCapture}
          disabled={isCapturing || isInitializing}
          className={`group relative flex items-center justify-center w-20 h-20 rounded-full border-4 border-white transition-all active:scale-95 ${isCapturing || isInitializing ? 'opacity-50 grayscale cursor-not-allowed' : 'hover:scale-105'}`}
        >
          <div className="w-16 h-16 rounded-full bg-white group-hover:bg-zinc-200 transition-colors shadow-2xl"></div>
          {isCapturing && (
            <div className="absolute inset-0 flex items-center justify-center">
               <i className="fas fa-circle-notch fa-spin text-zinc-900 text-2xl"></i>
            </div>
          )}
        </button>
      </div>

      {/* Hidden canvas for capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Top Banner */}
      <div className="absolute top-0 left-0 right-0 p-6 bg-gradient-to-b from-black/90 to-transparent z-20">
        <h1 className="text-white text-lg font-bold flex items-center gap-2 tracking-tight">
            <i className="fas fa-ruler-combined text-yellow-400"></i>
            Gemini Lens
        </h1>
        <p className="text-zinc-400 text-[10px] font-bold uppercase tracking-widest mt-1">Ready for measurement</p>
      </div>
      
      {/* Measurement Tip */}
      <div className="absolute bottom-36 left-0 right-0 px-8 flex justify-center pointer-events-none z-20">
          <div className="bg-black/40 backdrop-blur-md px-4 py-2 rounded-full border border-white/5 flex items-center gap-3 text-[10px] text-zinc-300 uppercase tracking-wide">
             <i className="fas fa-lightbulb text-yellow-400"></i>
             <span>Include a coin or card for scale</span>
          </div>
      </div>
    </div>
  );
};

export default CameraFeed;

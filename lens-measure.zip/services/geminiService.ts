
import { GoogleGenAI, Type } from "@google/genai";
import { MeasurementResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const estimateMeasurement = async (base64Image: string): Promise<MeasurementResult> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/jpeg',
              data: base64Image,
            },
          },
          {
            text: "Analyze this image and estimate the physical dimensions of the primary object in focus. Look for contextual clues like hands, common household items, or textures to judge scale. If the user has placed a reference object like a coin or card, use it. Return the dimensions in a structured JSON format.",
          },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            objectName: { type: Type.STRING, description: "Name of the object measured" },
            width: { type: Type.STRING, description: "Estimated width with units" },
            height: { type: Type.STRING, description: "Estimated height with units" },
            depth: { type: Type.STRING, description: "Estimated depth with units if applicable" },
            unit: { type: Type.STRING, enum: ['cm', 'inches', 'meters'], description: "The unit used for estimation" },
            confidence: { type: Type.NUMBER, description: "Confidence score from 0 to 1" },
            reasoning: { type: Type.STRING, description: "Brief explanation of how the scale was determined" },
          },
          required: ["objectName", "width", "height", "unit", "confidence", "reasoning"],
        },
      },
    });

    const result = JSON.parse(response.text || "{}");
    return result as MeasurementResult;
  } catch (error) {
    console.error("Gemini measurement error:", error);
    throw new Error("Failed to analyze image. Please try again.");
  }
};
